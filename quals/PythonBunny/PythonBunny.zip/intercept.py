
class Interceptor:
    def __init__(self):
        pass

    def intercept(self,data,from_server):
        return data
